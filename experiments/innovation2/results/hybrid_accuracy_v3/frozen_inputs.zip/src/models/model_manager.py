"""
模型管理模块
负责模型的加载、初始化和管理
支持本地Qwen模型和GLM-4 API两种模式
"""

import torch
import base64
from transformers import AutoModelForCausalLM, AutoProcessor
from typing import Optional, Dict, Any
from .config import Config

_ZhipuAiClient = None


def _get_zhipu_client():
    global _ZhipuAiClient
    if _ZhipuAiClient is None:
        try:
            from zai import ZhipuAiClient
            _ZhipuAiClient = ZhipuAiClient
        except ImportError:
            raise ImportError("请安装 zai-sdk: pip install zai-sdk")
    return _ZhipuAiClient


class ModelManager:
    """模型管理器，负责加载和管理Qwen3.5模型或GLM-4 API"""
    
    def __init__(self, config: Optional[Config] = None):
        self.config = config or Config()
        self.model = None
        self.processor = None
        self._is_loaded = False
        self._glm_client = None
    
    def load_model(self):
        """加载模型和处理器"""
        if self._is_loaded:
            print("模型已加载，跳过重复加载")
            return
        
        model_type = self.config.model.model_type
        
        if model_type == "glm":
            print("--- 使用 GLM-4 API 模式 ---")
            self._glm_client = None
            self._is_loaded = True
            print("--- GLM-4 API 配置已就绪 ---")
        else:
            print("--- 正在加载 Qwen 3.5-9B 模型 ---")
            
            self.processor = AutoProcessor.from_pretrained(
                self.config.model.model_path,
                trust_remote_code=self.config.model.trust_remote_code
            )
            
            self.model = AutoModelForCausalLM.from_pretrained(
                self.config.model.model_path,
                **self.config.get_model_kwargs()
            ).eval()
            
            self._is_loaded = True
            print("--- 模型加载完成 ---")
    
    def get_model(self):
        """获取模型实例"""
        if not self._is_loaded:
            self.load_model()
        return self.model
    
    def get_processor(self):
        """获取处理器实例"""
        if not self._is_loaded:
            self.load_model()
        return self.processor
    
    def is_loaded(self) -> bool:
        """检查模型是否已加载"""
        return self._is_loaded
    
    def unload_model(self):
        """卸载模型释放内存"""
        if self._is_loaded:
            if self.config.model.model_type == "qwen":
                del self.model
                del self.processor
                self.model = None
                self.processor = None
                torch.cuda.empty_cache()
            self._glm_client = None
            self._is_loaded = False
            print("--- 模型已卸载 ---")
    
    def is_glm_mode(self) -> bool:
        """检查是否使用GLM-4 API模式"""
        return self.config.model.model_type == "glm"
    
    def call_glm_api(self, messages: list, temperature: "Optional[float]" = None) -> str:
        """调用GLM-4 API进行推理。temperature为None时使用API默认（保持兼容）。"""
        ZhipuAiClient = _get_zhipu_client()

        if self._glm_client is None:
            self._glm_client = ZhipuAiClient(api_key=self.config.model.glm_api_key)

        model_name = self.config.model.glm_model_name

        try:
            print(f"--- 正在调用 GLM-4 API (模型: {model_name}) ---")

            kwargs = {
                "model": model_name,
                "messages": messages,
                "max_tokens": self.config.generation.max_new_tokens,
            }
            if temperature is not None:
                kwargs["temperature"] = temperature

            response = self._glm_client.chat.completions.create(**kwargs)
            if response is None:
                raise RuntimeError("API返回为空")
            if not hasattr(response, 'choices') or not response.choices:
                raise RuntimeError(f"API响应格式错误: {response}")
            return response.choices[0].message.content
        except Exception as e:
            import traceback
            traceback.print_exc()
            if hasattr(e, 'response') and e.response:
                try:
                    print(f"--- 响应状态码: {e.response.status_code} ---")
                    print(f"--- 响应内容: {e.response.text[:2000]} ---")
                except:
                    pass
            raise RuntimeError(f"GLM-4 API调用失败: {str(e)}")